package com.cenfotec.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompleteCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompleteCrudApplication.class, args);
	}

}
