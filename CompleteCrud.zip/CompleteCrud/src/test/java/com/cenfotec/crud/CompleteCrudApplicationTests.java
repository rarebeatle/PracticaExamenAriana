package com.cenfotec.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompleteCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
